import heapq
import math

def dijkstra(graph, source):
    # TODO 1: validar el origen y los costos no negativos.
    # TODO 2: inicializar distancias y cola de prioridad.
    # TODO 3: relajar aristas y devolver costos para nodos alcanzables.
    pass

def shortest_path(graph, source, target):
    # TODO 4: implementar Dijkstra guardando predecesores.
    # TODO 5: reconstruir la ruta; devolver [] si no hay ruta.
    pass
