import argparse, uuid #recibir argumentos por línea de comandos
from routing import shortest_path
from topology import GRAPH, HEADERS
from transport import send_reliably

def build_transaction(card_id, amount, station):
    "Recibe el identificador de la tarjeta, el importe y la estación donde está el molinete."
    # TODO 1: validar monto y estación.
    # TODO 2: elegir la cabecera alcanzable de menor costo.
    # TODO 3: generar transaction_id y construir la transacción.
    pass

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--card", default="SUBE-001")
    parser.add_argument("--amount", type=float, default=100)
    parser.add_argument("--station", default="Medrano")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=19000)
    args = parser.parse_args()
    tx = build_transaction(args.card, args.amount, args.station)
    print("Transacción:", tx)
    try: print("Respuesta:", send_reliably((args.host,args.port),tx,seq=1,timeout=1,max_retries=3))
    except TimeoutError as exc: print("No se pudo completar el cobro:", exc)

if __name__ == "__main__": main()
